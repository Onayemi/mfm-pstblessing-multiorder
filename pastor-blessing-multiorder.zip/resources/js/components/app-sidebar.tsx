import { Link } from "@inertiajs/react";
import {
    LayoutGrid,
    Calendar,
    UserPlus,
    BarChart3,
    FolderGit2,
    BookOpen,
} from "lucide-react";
import AppLogo from "@/components/app-logo";
// import { NavFooter } from "@/components/nav-footer";
import { NavMain } from "@/components/nav-main";
import { NavUser } from "@/components/nav-user";
import {
    Sidebar,
    SidebarContent,
    SidebarFooter,
    SidebarHeader,
    SidebarMenu,
    SidebarMenuButton,
    SidebarMenuItem,
} from "@/components/ui/sidebar";
import { dashboard } from "@/routes";
import type { NavItem } from "@/types";
import { NavFooter } from "./nav-footer";

const mainNavItems: NavItem[] = [
    {
        title: "Dashboard",
        href: dashboard(),
        icon: LayoutGrid,
    },
    {
        title: "Manage Bookings",
        href: "/admin/bookings",
        icon: Calendar,
    },
    {
        title: "Manage New Account",
        href: "/admin/staff",
        icon: UserPlus,
    },
    {
        title: "Reports",
        href: "/admin/reports",
        icon: BarChart3,
    },
];

const footerNavItems: NavItem[] = [
    // {
    //     title: "Repository",
    //     href: "https://github.com/laravel/react-starter-kit",
    //     icon: FolderGit2,
    // },
    // {
    //     title: "Documentation",
    //     href: "https://laravel.com/docs/starter-kits#react",
    //     icon: BookOpen,
    // },
];

export function AppSidebar() {
    return (
        <Sidebar collapsible="icon" variant="inset">
            <SidebarHeader>
                <SidebarMenu>
                    <SidebarMenuItem>
                        <SidebarMenuButton size="lg" asChild>
                            <Link href={dashboard()} prefetch>
                                <AppLogo />
                            </Link>
                        </SidebarMenuButton>
                    </SidebarMenuItem>
                </SidebarMenu>
            </SidebarHeader>

            <SidebarContent>
                <NavMain items={mainNavItems} />
            </SidebarContent>

            <SidebarFooter>
                {/* <NavFooter items={footerNavItems} className="mt-auto" /> */}
                <NavUser />
            </SidebarFooter>
        </Sidebar>
    );
}
