import { usePage } from "@inertiajs/react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { useInitials } from "@/hooks/use-initials";
import type { User } from "@/types";

interface UserInfoProps {
    user?: User | null;
    showEmail?: boolean;
}

export function UserInfo({ user, showEmail = false }: UserInfoProps) {
    const { auth } = usePage<{ auth?: { user?: User | null } }>().props;
    const currentUser = user ?? auth?.user;
    const getInitials = useInitials();

    if (!currentUser) {
        return null;
    }

    const displayName = currentUser.name || "User";
    const initials = getInitials(displayName);

    return (
        <>
            <Avatar className="h-8 w-8 overflow-hidden rounded-full">
                <AvatarImage src={currentUser.avatar} alt={displayName} />
                <AvatarFallback className="rounded-lg bg-neutral-200 text-black dark:bg-neutral-700 dark:text-white">
                    {initials}
                </AvatarFallback>
            </Avatar>
            <div className="grid flex-1 text-left text-sm leading-tight">
                <span className="truncate font-medium">{displayName}</span>
                {showEmail && currentUser.email && (
                    <span className="text-muted-foreground truncate text-xs">
                        {currentUser.email}
                    </span>
                )}
            </div>
        </>
    );
}
