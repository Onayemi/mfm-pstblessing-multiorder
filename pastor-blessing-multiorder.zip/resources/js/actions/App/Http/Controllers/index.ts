import HomeController from './HomeController'
import SitemapController from './SitemapController'
import Admin from './Admin'
import Settings from './Settings'
const Controllers = {
    HomeController: Object.assign(HomeController, HomeController),
SitemapController: Object.assign(SitemapController, SitemapController),
Admin: Object.assign(Admin, Admin),
Settings: Object.assign(Settings, Settings),
}

export default Controllers