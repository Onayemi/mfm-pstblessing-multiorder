import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../../wayfinder'
/**
* @see \App\Http\Controllers\Admin\ReportController::reportIndex
 * @see app/Http/Controllers/Admin/ReportController.php:80
 * @route '/admin/reports'
 */
export const reportIndex = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportIndex.url(options),
    method: 'get',
})

reportIndex.definition = {
    methods: ["get","head"],
    url: '/admin/reports',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ReportController::reportIndex
 * @see app/Http/Controllers/Admin/ReportController.php:80
 * @route '/admin/reports'
 */
reportIndex.url = (options?: RouteQueryOptions) => {
    return reportIndex.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ReportController::reportIndex
 * @see app/Http/Controllers/Admin/ReportController.php:80
 * @route '/admin/reports'
 */
reportIndex.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: reportIndex.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ReportController::reportIndex
 * @see app/Http/Controllers/Admin/ReportController.php:80
 * @route '/admin/reports'
 */
reportIndex.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: reportIndex.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ReportController::reportIndex
 * @see app/Http/Controllers/Admin/ReportController.php:80
 * @route '/admin/reports'
 */
    const reportIndexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: reportIndex.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ReportController::reportIndex
 * @see app/Http/Controllers/Admin/ReportController.php:80
 * @route '/admin/reports'
 */
        reportIndexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportIndex.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ReportController::reportIndex
 * @see app/Http/Controllers/Admin/ReportController.php:80
 * @route '/admin/reports'
 */
        reportIndexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: reportIndex.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    reportIndex.form = reportIndexForm
/**
* @see \App\Http\Controllers\Admin\ReportController::exportCsv
 * @see app/Http/Controllers/Admin/ReportController.php:93
 * @route '/admin/reports/export'
 */
export const exportCsv = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})

exportCsv.definition = {
    methods: ["get","head"],
    url: '/admin/reports/export',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\Admin\ReportController::exportCsv
 * @see app/Http/Controllers/Admin/ReportController.php:93
 * @route '/admin/reports/export'
 */
exportCsv.url = (options?: RouteQueryOptions) => {
    return exportCsv.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\Admin\ReportController::exportCsv
 * @see app/Http/Controllers/Admin/ReportController.php:93
 * @route '/admin/reports/export'
 */
exportCsv.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: exportCsv.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\Admin\ReportController::exportCsv
 * @see app/Http/Controllers/Admin/ReportController.php:93
 * @route '/admin/reports/export'
 */
exportCsv.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: exportCsv.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\Admin\ReportController::exportCsv
 * @see app/Http/Controllers/Admin/ReportController.php:93
 * @route '/admin/reports/export'
 */
    const exportCsvForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: exportCsv.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\Admin\ReportController::exportCsv
 * @see app/Http/Controllers/Admin/ReportController.php:93
 * @route '/admin/reports/export'
 */
        exportCsvForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\Admin\ReportController::exportCsv
 * @see app/Http/Controllers/Admin/ReportController.php:93
 * @route '/admin/reports/export'
 */
        exportCsvForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: exportCsv.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    exportCsv.form = exportCsvForm
const ReportController = { reportIndex, exportCsv }

export default ReportController