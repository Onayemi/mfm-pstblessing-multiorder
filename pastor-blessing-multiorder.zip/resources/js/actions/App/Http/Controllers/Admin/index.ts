import DashboardController from './DashboardController'
import BookingController from './BookingController'
import StaffController from './StaffController'
import ReportController from './ReportController'
const Admin = {
    DashboardController: Object.assign(DashboardController, DashboardController),
BookingController: Object.assign(BookingController, BookingController),
StaffController: Object.assign(StaffController, StaffController),
ReportController: Object.assign(ReportController, ReportController),
}

export default Admin