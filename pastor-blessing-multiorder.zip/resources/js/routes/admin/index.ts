import staff from './staff'
const admin = {
    staff: Object.assign(staff, staff),
}

export default admin